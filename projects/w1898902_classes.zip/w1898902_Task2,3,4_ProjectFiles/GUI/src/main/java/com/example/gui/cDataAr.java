//I declare that my work contains no examples of misconduct, such as
//plagiarism, or collusion.
//Any code taken from other sources is referenced within my code solution.
//Student ID: w1898902
//7/8/2022
package com.example.gui;

public class cDataAr {
    public  cData[] c = new cData[6];
}
